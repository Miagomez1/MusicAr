﻿namespace MusicAr.AuthService.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Pass { get; set; } = string.Empty;
    }
}
